package com.capgemini.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.servlets.dao.ProductDao;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("username", username);
		httpSession.getId();
		
		Cookie cookie = new Cookie("username", username);
		Cookie cookie2 = new Cookie("password", password);
		response.addCookie(cookie);
		response.addCookie(cookie2);
		
		ServletContext servletContext = getServletContext();
		/*try {
			Class.forName(servletContext.getInitParameter("driver_class"));
			String url = servletContext.getInitParameter("url");
			String user = servletContext.getInitParameter("username");
			String pass = servletContext.getInitParameter("password");
			Connection connection = DriverManager.getConnection(url, user, pass);
			System.err.println("Successssssssss////////////");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		ServletConfig servletConfig = getServletConfig();
		if (username.equals(servletConfig.getInitParameter("username")) && password.equals(servletConfig.getInitParameter("password"))) {*/
//		/if (username.equals("aniimal") && password.equals("456")) {
		ProductDao dao = new ProductDao();
		boolean flag = dao.validate(username, password);
		if(flag) {
			response.sendRedirect("home.jsp");
			// requestDispatcher.forward(request, response);
		} else {
			out.println("<b style='color:FF6347'>USername/password is incorrect");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
			requestDispatcher.include(request, response);

		}

	}

}
