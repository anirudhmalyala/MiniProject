package com.capgemini.servlets.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServlet;

public class ProductDao extends HttpServlet {

	Connection connection = null;
	PreparedStatement statement = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String username = "system";
			String password = "Capgemini123";
			connection = DriverManager.getConnection(url, username, password);

			return connection;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public int add(String username, String password, String email, String mobile) {
		connection = getConnection();
		String sql = "INSERT INTO user_details VALUES(?,?,?,?)";

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, username);
			statement.setString(2, password);
			statement.setString(3, email);
			statement.setString(4, mobile);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;

	}

	public boolean validate(String username, String password) {
		try {
			connection = getConnection();
			String sql = "SELECT *FROM USER_DETAILS WHERE password=?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, password);
			ResultSet rs = statement.executeQuery();
			return rs.next();
		} catch (Exception e) {
		}
		return false;

	}

	public int addp(String id, String productName, String price, String model) {
		connection = getConnection();
		String sql = "INSERT INTO product_details VALUES(?,?,?,?)";

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(4, id);
			statement.setString(1, productName);
			statement.setString(2, price);
			statement.setString(3, model);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;

	}

	public boolean validatePassword(String username, String mobile) {
		try {
			connection = getConnection();
			String sql = "SELECT *FROM USER_DETAILS WHERE mobile=?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, mobile);

			ResultSet rs = statement.executeQuery();
			return rs.next();
		} catch (Exception e) {
		}
		return false;

	}

	public int newPass(String mobile, String password) {
		// TODO Auto-generated method stub
		connection = getConnection();
		String sql = "UPDATE user_details SET password=? WHERE mobile=?";
		try {

			statement = connection.prepareStatement(sql);
			statement.setString(2, mobile);
			statement.setString(1, password);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int editP(String id, String price) {
		connection = getConnection();
		String sql = "UPDATE product_details SET price=? WHERE id=?";

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(2, id);
			statement.setString(1, price);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int deletep(String id, String productName, String price, String model) {
		connection = getConnection();
		String sql = "DELETE FROM product_details WHERE id=?";

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, id);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;

	}

}
