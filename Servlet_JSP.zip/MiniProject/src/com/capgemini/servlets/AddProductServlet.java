package com.capgemini.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.servlets.dao.ProductDao;

/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String productName = request.getParameter("productName");
		String price = request.getParameter("price");
		String model = request.getParameter("model");
		
		ProductDao dao = new ProductDao();
		int n = dao.addp(id, productName, price, model);
		if (n > 0) {
			out.println("<b style='color:FF6347'>Product has been added successfully");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("home.jsp");
			requestDispatcher.include(request, response);
	}else {
		response.sendRedirect("register.jsp?emsg=Something might went wrong");
	}

}
}
