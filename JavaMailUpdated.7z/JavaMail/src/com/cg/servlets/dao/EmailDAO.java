package com.cg.servlets.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServlet;

public class EmailDAO extends HttpServlet {

	Connection connection = null;
	PreparedStatement statement = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String username = "system";
			String password = "Capgemini123";
			connection = DriverManager.getConnection(url, username, password);

			return connection;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public boolean validateLogin(String username, String password) {
		try {
			connection = getConnection();
			String sql = "SELECT *FROM EMAIL_REGISTRATION WHERE password=?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, password);
			ResultSet resultSet = statement.executeQuery();
			return resultSet.next();
		} catch (Exception e) {
		}
		return false;
	}

	public int register(String username, String password, String email) {
		connection = getConnection();
		String sql = "INSERT INTO EMAIL_REGISTRATION VALUES(?,?,?)";

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, username);
			statement.setString(2, password);
			statement.setString(3, email);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public boolean validatePassword(String username, String email) {
		// TODO Auto-generated method stub
		try {
			connection = getConnection();
			String sql = "SELECT *FROM EMAIL_REGISTRATION WHERE email=?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, email);

			ResultSet rs = statement.executeQuery();
			return rs.next();
		} catch (Exception e) {
		}
		return false;

	}

	public int createNewPassword(String email, String password) {
		connection = getConnection();
		String sql = "UPDATE EMAIL_REGISTRATION SET password=? WHERE email=?";
		try {

			statement = connection.prepareStatement(sql);
			statement.setString(1, password);
			statement.setString(2, email);

			int n = statement.executeUpdate();

			return n;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
