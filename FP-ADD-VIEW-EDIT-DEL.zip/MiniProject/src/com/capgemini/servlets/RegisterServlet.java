package com.capgemini.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.servlets.dao.ProductDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		/*
		 * out.println("<html>"); out.println("<body bgcolor='fffff'>");
		 * out.println("<b style='color:008000'>User's registered successfully.");
		 * out.println("</body></html>"); RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("login.jsp"); requestDispatcher.include(request,
		 * response);
		 */
		ProductDao dao = new ProductDao();
		
		int n = dao.add(username, password, email, mobile);
		if (n > 0) {
			// response.sendRedirect("login.jsp");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
			requestDispatcher.forward(request, response);
		} else {
			// response.sendRedirect("register.jsp?emsg=Something might went wrong");
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher("register.jsp?emsg=Something might went wrong");
			requestDispatcher.include(request, response);
		}

	}

}
