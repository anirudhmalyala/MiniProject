package com.capgemini.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.servlets.dao.ProductDao;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

/**
 * Servlet implementation class FPassword2
 */
@WebServlet("/FPassword2")
public class FPassword2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FPassword2() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//String username = request.getParameter("username");
		String mobile = request.getParameter("mobile");
		String password = request.getParameter("password");
		String confpass = request.getParameter("confpass");
		if(password.equals(confpass)) {
			ProductDao dao = new ProductDao();
		int n = dao.newPass(mobile, password);
		if (n > 0) {
				out.println("<b style='color:green'>Update Successful.</b>");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
				requestDispatcher.include(request, response);
			}else {
				response.sendRedirect("forgotpass.jsp?emsg=Something might went wrong");
			}
		}
		else {
			out.println("<b style='color:FF6347'>Both password fields should be same.");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("newpass.jsp");
			requestDispatcher.include(request, response);
		}
		
		
	}
}
